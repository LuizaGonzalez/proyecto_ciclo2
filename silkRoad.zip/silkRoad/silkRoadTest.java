import static org.junit.Assert.*;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

/**
 * The test class silkRoadTest.
 *
 * @author  (your name)
 * @version (a version number or a date)
 */
public class silkRoadTest
{
    
    @Test
    public void shouldCreatedRoadInputMaraton(){
        int [][] days = {{1, 20},{2,15,15},{2,40,50},{1,50},{2,80,20},{2, 70, 30}};
        silkRoad road = new silkRoad(days);
        int[][] tiendas = road.stores();
        int[][] robots = road.robots();
        assertNotNull(road);
        assertEquals(20, robots[0][0]);
        assertEquals(50, robots[1][0]);
        assertEquals(15, tiendas[0][0]); 
        assertEquals(15, tiendas[0][1]); 
        assertEquals(40, tiendas[1][0]);   
        assertEquals(50, tiendas[1][1]); 
        assertEquals(70, tiendas[2][0]); 
        assertEquals(30, tiendas[2][1]); 
        assertEquals(80, tiendas[3][0]); 
        assertEquals(20, tiendas[3][1]);
        assertTrue(road.oK());
        
    }
    
    @Test
    public void shouldCreatedRoadEmpty(){
        int[][] days = {};
        silkRoad road = new silkRoad(days);
        assertNotNull("La ruta no debería ser null", road);
        int[][] robots = road.robots();
        assertEquals(0, road.profit());
        assertTrue(road.oK());
    }
    
    @Test
    public void shouldMoveRobotToMostProfitableStore() {
        silkRoad road = new silkRoad(30);
        road.placeStore(10, 30);  
        road.placeStore(20, 20); 
        road.placeRobot(15);
        
        road.moveRobots();
        int[][] robotsActuales = road.robots();
        assertEquals(1, robotsActuales.length);
        assertEquals(10, robotsActuales[0][0]);
    }
    
}
