import java.util.ArrayList;
import java.util.Random;
/**
 * Tiendas para la ruta de seda
 * 
 * @author (Luiza Gonzalez - Camilo Leon ) 
 * @version (6 de septiembre del 2025)
 */
public class Store{
    private int outshop;
    private int width;
    private int height;
    private String colorStore;
    private int LocationStore;
    private int tenges;
    private int currentTenges;
    private Rectangle tienda;
    private int x;
    private int y;
    private static ArrayList<String> usedColors = new ArrayList<>();
    private static final String[] availableColors = {"red", "yellow", "blue","green", "black", "darkGray", "lightGray", "orange", "cyan"};
    //ciclo2
    private int unoccupiedShop; //lleva la cuenta de cuantas veces ha sido desocupada la tienda
    /**
     * Contructor de la clase Store.
     * @param LocationStore posicion en x inicial.
     * @param tenges monedas iniciales.
     */
    public Store(int LocationStore, int tenges){
        this.width=20;
        this.height=30;
        this.LocationStore = LocationStore;
        this.tenges = tenges;
        this.currentTenges = tenges;
        this.colorStore = unicoColor();
        this.tienda = new Rectangle();
        tienda.changeSize(height,width);
        tienda.moveHorizontal(LocationStore);
        tienda.moveVertical(5);
        tienda.changeColor(colorStore);
        tienda.makeVisible();
        this.unoccupiedShop = 0;
    }
    
    private String unicoColor() {
        Random random = new Random();
        
        String selectedColor;
        //Aigen
        do {
            int index = random.nextInt(availableColors.length);
            selectedColor = availableColors[index];
        } while (usedColors.contains(selectedColor));
        
        usedColors.add(selectedColor);
        return selectedColor;
    }
    
    //Marca que un robot salió de la tienda.
    public void markOutShop(){
        unoccupiedShop++;
    }
    
    //Devuelve cuántas veces esta tienda fue desocupada.
    public int contOutStore(){
        return unoccupiedShop;
    }
    
    public int getLocationStore() {
        return LocationStore; 
    } 
    
    /**
     * obtiene la altura.
     */
    public int getHeight(){
        return height;
    }
    
    /**
     * obtiene el ancho.
     */
    public int getWidth(){
        return width; 
    }
    
    /**
     * Obtiene el color asignado.
     */
    public String getColorStore(){
        return colorStore;
    }
    
    
    /**Cambia la ubicación.
     * 
     */
    public void setLocationStore(int newLocation){
        this.LocationStore = newLocation;
    }
    
    /**Obtiene la cantidad total de tenges acumulados.
     * 
     */
    public int getTenges() {
        return tenges;
    }
    
    /**Establece la cantidad total de tenges.
     * @param tenges monedas que quiere actualizar.
     */
    public void setTenges(int tenges) {
        this.tenges = tenges;
    }
    
    /**Obtiene la cantidad actual de tenges disponibles.
     * 
     */
    public int getCurrentTenges() {
        return currentTenges;
    }
    
    /**Cambia la cantidad actual de tenges disponibles.
     * @param currentTenges monedas actuales.
     */
    public void setCurrentTenges(int currentTenges) {
        this.currentTenges = currentTenges;
    }
    
    /**Establece la cantidad de tenges a agregar.
     * @param montoTenges monedas que se quiere añadir.
     */
    public void addTenges(int montoTenges){
       this.currentTenges += montoTenges;
    }
    
     /**Cambia el tamaño de la tienda
     * @param newHeight nueva altura de la tienda.
     * @param newWidth  nuevo ancho de la tienda.
     */
    public void changeSize(int newHeight , int newWidth){
        height = newHeight;
        width = newWidth;
        tienda.changeSize(newHeight,newWidth);
    }
    
    /**
     * Hace visible la tienda en el canvas
     */
    public void makeVisible() {
        tienda.makeVisible();
    }
    
    /**
     * Hace invisible la tienda en el canvas
     */
    public void makeInvisible() {
        tienda.makeInvisible();
    }
    
    public int reduceTenges(int meters) {
        int actualReduction = meters;
        currentTenges -= actualReduction;
        return actualReduction;
    }
    
    public void moveTo(int x, int y) {
        this.x = x;
        this.y = y;
        tienda.moveHorizontal(x);
        tienda.moveVertical(y);
    }
    
    /**
     * Obtiene el número de veces que ha sido desocupada
     */
    public int getTimesUnoccupied() {
        return unoccupiedShop;
    }
}